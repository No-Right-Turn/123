// ==UserScript==
// @name         上仙纪念币预约自动填充（多组数据支持全部银行）
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  自动填充网页中的姓名、身份证号和手机号，支持多组数据
// @author       上仙社区版权 vx：sxian0001  侵权必究！！！
// @match        *://*/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

    const expirationDate = new Date('2024-12-23T23:59:59').getTime();//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

    const currentTime = new Date().getTime();
    if (currentTime > expirationDate) {//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        alert('今年蛇钞到此为之了，没有加上仙VX:sxian0001,可以加一下避免失联！');
        return; //上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    }
//上仙社区版权 vx：sxian0001       侵权必究！！！
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    const toggleFloatingWindowButton = document.createElement('button');//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    toggleFloatingWindowButton.className = 'autofill-button';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    toggleFloatingWindowButton.textContent = '悬浮窗开关';
    toggleFloatingWindowButton.style.position = 'fixed';
    toggleFloatingWindowButton.style.bottom = '60px'; //上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    toggleFloatingWindowButton.style.right = '10px';
    toggleFloatingWindowButton.style.zIndex = '1001';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    toggleFloatingWindowButton.style.padding = '10px';
    toggleFloatingWindowButton.style.background = 'linear-gradient(to right, #228B22, #66CDAA)';
    toggleFloatingWindowButton.style.color = '#fff';
    toggleFloatingWindowButton.style.border = 'none';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    toggleFloatingWindowButton.style.borderRadius = '5px';
    toggleFloatingWindowButton.style.cursor = 'pointer';

    toggleFloatingWindowButton.addEventListener('click', () => {//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        const autofillButtons = document.querySelector('.autofill-buttons');
        if (autofillButtons) {
            autofillButtons.style.display = autofillButtons.style.display === 'none' ? 'flex' : 'none';
        }
    });

    document.body.appendChild(toggleFloatingWindowButton);

//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    const donateButton = document.createElement('button');
    donateButton.className = 'autofill-button';
    donateButton.textContent = '打赏作者';
    donateButton.style.position = 'fixed';
    donateButton.style.bottom = '110px'; 
    donateButton.style.right = '10px';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    donateButton.style.zIndex = '1001';
    donateButton.style.padding = '10px';
    donateButton.style.background = 'linear-gradient(90deg, red, orange, yellow, green, blue, indigo, violet)';
    donateButton.style.color = '#fff';
    donateButton.style.border = 'none';
    donateButton.style.borderRadius = '5px';//上仙社区版权 vx：sxian0001       侵权必究！！！
    donateButton.style.cursor = 'pointer';
    donateButton.style.backgroundSize = '400% 100%';
    donateButton.style.animation = 'rainbowBackground 5s linear infinite';

    donateButton.addEventListener('click', () => {
        createAnnouncement();
    });

    document.body.appendChild(donateButton);//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

    var floatButton = document.createElement('button');
    floatButton.innerHTML = '点击获取验证码';
    floatButton.style.position = 'fixed';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    floatButton.style.bottom = '10px';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：s//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！xian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    floatButton.style.right = '10px';
    floatButton.style.zIndex = '1000';
    floatButton.style.padding = '10px';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    floatButton.style.backgroundColor = '#f00';
    floatButton.style.color = '#fff';
    floatButton.style.border = 'none';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    floatButton.style.borderRadius = '5px';
    floatButton.style.cursor = 'pointer';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！权必究！！！

    document.body.appendChild(floatButton);//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

    floatButton.addEventListener('click', function() {

        var selectors = [
            '.free_get ml20 next',//建设
            '#free_get ml20 next',//建设
            'free_get ml20 next',//建设
            '.to_code',//建设
            'to_code',//建设
            '#to_code',//建设
            'btn-submit',//农业
            '.btn-submit',//农业
            '#btn-submit',//农业
            'forCashInfor_fillbtn',
            '.forCashInfor_fillbtn',//中国银行
            '#forCashInfor_fillbtn',//中国银行
            'link4Verifyimage2Name',//gs
            '.link4Verifyimage2Name',//gs
            '#link4Verifyimage2Name',//gs
            '.el-button.el-button--text.append-text'
        ];

        // 遍历选择器列表，查找并点击按钮//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        selectors.forEach(function(selector) {//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            var buttons = document.querySelectorAll(selector);
            buttons.forEach(function(button) {
                button.click(); // 点击按钮//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian00//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！1       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                console.log('按钮已点击: ' + selector);//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            });
        });//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    });

    // 添加样式
    GM_addStyle(`
    .autofill-settings {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0,0,0,0.3);
        z-index: 10001;
        display: none;
        max-width: 90vw;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
    }
    .autofill-settings::-webkit-scrollbar {
        width: 8px;
    }
    .autofill-settings::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }
    .autofill-settings::-webkit-scrollbar-thumb {
        background: #888;
        border-radius: 4px;
    }
    .autofill-settings::-webkit-scrollbar-thumb:hover {
        background: #555;
    }
    .autofill-settings h2 {
        margin-top: 0;
        margin-bottom: 20px;
        color: #333;
        position: sticky;
        top: 0;
        background: white;
        padding: 10px 0;
        z-index: 1;
    }
    .autofill-settings .grid-container {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 10px;
    }
    .autofill-settings .group {
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background: #f9f9f9;
    }
    .autofill-settings .group h3 {
        margin-top: 0;
        margin-bottom: 10px;
        color: #444;
        font-size: 14px;
    }
    .autofill-settings label {
        display: block;
        margin-bottom: 5px;
        color: #666;
        font-size: 12px;
    }
    .autofill-settings input {
        width: calc(100% - 12px);
        padding: 6px;
        margin-bottom: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 12px;
    }
    .autofill-settings input:focus {
        border-color: #4CAF50;
        outline: none;
        box-shadow: 0 0 3px rgba(76, 175, 80, 0.3);
    }
    .autofill-settings .buttons {
        text-align: right;
        margin-top: 15px;
        position: sticky;
        bottom: 0;
        background: white;
        padding: 10px 0;
        border-top: 1px solid #eee;
    }
    .autofill-settings button {
        padding: 8px 20px;
        margin-left: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }
    .autofill-settings .save {
        background: #4CAF50;
        color: white;
    }
    .autofill-settings .save:hover {
        background: #45a049;
    }
    .autofill-settings .cancel {
        background: #f44336;
        color: white;
    }
    .autofill-settings .cancel:hover {
        background: #da190b;
    }
    .autofill-buttons {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .autofill-button {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        transition: background-color 0.3s;
    }
    .autofill-button:hover {
        background-color: #45a049;
    }
    .settings-button {
        background-color: #2196F3 !important;
    }
    .settings-button:hover {
        background-color: #1976D2 !important;
    }
    `);
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

    const defaultData = {//上仙社区版权 vx：sxian0001       侵权必究！！！
        groups: Array.from({ length: 10 }, () => ({
            name: '',
            idCard: '',//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            phone: '',
            bankBranch: '',
            reservationAmount: '',//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            note: ''
        }))
    };//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
    let savedData = GM_getValue('autofillData', defaultData);

//上仙社区版权 vx：sxian0001       侵权必究！！！
    function createSettingsPanel() {//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        const panel = document.createElement('div');//上仙社区版权 vx：sxian0001       侵权必究！！！
        panel.className = 'autofill-settings';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
//上仙社区版权 vx：sxian0001       侵权必究！！！
        let html = `
        <style>
        .btm {
            background: rgba(255, 255, 255, 0.2); 
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(3px); 
            -webkit-backdrop-filter: blur(10px); 
            padding: 20px;
            width: 600px;
            text-align: center;
            color: #fff;
            font-family: 'Arial', sans-serif;
            margin: 0 auto;
            }

        .btm-1 {
            background: rgba(255, 255, 255, 0.2); 
            border-radius: 15px; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(30px); 
            -webkit-backdrop-filter: blur(10px); 
            padding: 20px;
            width: 400px;
            text-align: center;
            color: #fff;
            font-family: 'Arial', sans-serif;
            margin: 0 auto;
            }

        .btm-2 {
            background: rgba(255, 255, 255, 0.2); /* 半透明白色背景 */
            border-radius: 15px; /* 圆角 */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(3px); /* 背景模糊效果 */
            -webkit-backdrop-filter: blur(10px); /* 兼容Safari */
            padding: 10px;
            width: 300px;
            text-align: center;
            color: #fff;
            font-family: 'Arial', sans-serif;
            }

        h4 {
        text-align: center; /* 文本居中 */
        font-size: 20px;
        }
        h3 {
        font-size: 28px;
        }

        .image-container {
            text-align: center; /* 图片水平居中 */
            margin: 20px 0;
        }
        .image-container img {
            width: 100px; /* 设置图片宽度 */
            height: auto; /* 保持图片比例 */
            border-radius: 60px; /* 圆角 */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* 可选：添加阴影 */
        }
                .image-two {
            text-align: center; /* 图片水平居中 */
            margin: 20px 0;
        }
        .image-two img {
            width: 30px; /* 设置图片宽度 */
            height: auto; /* 保持图片比例 */
            cursor: pointer; /* 鼠标悬停时显示为手型 */
            transition: transform 0.3s; /* 添加过渡效果 */
        }
         .image-two img:hover {
            transform: scale(1.1); /* 鼠标悬停时放大 */
        }

  @keyframes rainbowBackground {
            0% { background-position: 0% 50%; }
            100% { background-position: 100% 50%; }
        }

        h1 {
            font-size: 35px;
            text-align: center;
            background: linear-gradient(90deg, red, orange, yellow, green, blue, indigo, violet);
            background-size: 400% 100%;
            -webkit-background-clip: text;
            color: transparent;
            animation: rainbowBackground 7s linear infinite;
        }
        </style>
                            <div class="image-container">
    <img src="https://img.picui.cn/free/2024/12/19/67632b4ba8264.png" alt="ikunkou.png" title="ikunkou.png" />
</div>
<div class="btm-1">
            <h1>上仙蛇钞预约小助手</h1>
            </div>
<br>
<div class="btm">
<h3>使用说明</h3>
            <h4>1.现在预约脚本支持PC/Android（不包括IOS）使用.
            <br>
            2.脚本填充现已支持全部纪念币承办银行，个别银行原因看下方.
            <br>
            （ps：长沙银行不支持原因：官方只支持微信打开预约）.
<br>
            （ps：邮储/苏州/徽商/陕西信合，由于官方没有开放测试，有可能个别单个信息会填写不上，一般不会出现失误，自己可以设置多个备选方案）.
            <br>
            3.脚本填充前需要在设置内，输入您要使用的每组数据.
            <br>
            4.右下角一键获取验证仅支持,建设/农业/工商/工商/中国/交通<br>（可能会个别失效）.
            <br>
            5.最近几天会经常更新功能,加快支持各行,由于不是热更新，需要加群随时关注动态.
            <br>
            6.修改前台悬浮的填充按钮的显示，改为只有填写数据的组，前端才显示该组的填充按钮，使用起来更加方便简洁.
            <br>
            7.此工具仅用于参考学习。
</h4>
            <div class="image-two">
<a href="https://h5.clewm.net/?url=qr61.cn%2FowNTZw%2FqMOHV09" target="_blank">
<img src="https://img.picui.cn/free/2024/12/19/67632c66de60b.ico"  title="点我联系作者" />
</a>
</div>

</div>
            </h3>
            <div class="btm-2">
                <h3>自动填充设置：</h3>
            </div>
            <br>
            <div class="grid-container">
        `;
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        // 创建10组数据的输入框
        savedData.groups.forEach((group, index) => {
            html += `
                <div class="group">
                    <h3>第 ${index + 1} 组数据</h3>
                    <label>姓名：</label>
                    <input type="text" class="name-input" data-group="${index}" value="${group.name}">
                    <label>身份证号：</label>
                    <input type="text" class="idcard-input" data-group="${index}" value="${group.idCard}">
                    <label>手机号：</label>
                    <input type="text" class="phone-input" data-group="${index}" value="${group.phone}">
                    <label>银行网点：<br>（严格按照银行公布网点名称填写，极个别部分银行下拉框需手动填写）</label>
                    <input type="text" class="branch-input" data-group="${index}" value="${group.bankBranch}">
                    <label>预约数量：（根据银行规则按需修改）</label>
                    <input type="text" class="amount-input" data-group="${index}" value="${group.reservationAmount}">
                    <label>备注：（会显示到对应组填充按钮上面，方便辨认此组信息，如果不需要可以为空不填。）</label>
                    <input type="text" class="note-input" data-group="${index}" value="${group.note}">
                </div>
            `;
        });
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        html += `
            <style>
.autofill-settings {
        background-image: url('https://haowallpaper.com/link/common/file/previewFileImg/15789130517090624'); /* 替换为你的背景图片URL */
        background-size: cover; /* 背景图片覆盖整个面板 */
        background-position: center; /* 背景图片居中 */
        background-repeat: no-repeat; /* 不重复背景图片 */
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0,0,0,0.3);
        z-index: 10001;
        display: none;
        max-width: 90vw;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
    }
        .floating-window {
            position: absolute; /* 绝对定位 */
            top: 310px; /* 距离容器顶部 */
            right: 20px; /* 距离容器右侧 */
            width: 200px;
            background: rgba(255, 255, 255, 0.2); /* 半透明白色背景 */
            border-radius: 15px; /* 圆角 */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px); /* 背景模糊效果 */
            -webkit-backdrop-filter: blur(10px); /* 兼容Safari */
            color: white;
            padding: 20px;
            z-index: 1000;
            font-family: 'Arial', sans-serif;
        }
        .floating-window p {
        text-align: center; /* 文本居中 */
            font-size: 18px;
            line-height: 1.5;
        }
        .but {
            margin: 0 auto; /* 元素水平居中 */
            padding: 20px;
        }

 @keyframes rainbowBackground {
            0% { background-position: 0% 50%; }
            100% { background-position: 100% 50%; }
        }

        h5 {
            font-size: 18px;
            text-align: center;
            background: linear-gradient(90deg, red, orange, yellow, green, blue, indigo, violet);
            background-size: 400% 100%;
            -webkit-background-clip: text;
            color: transparent;
            animation: rainbowBackground 7s linear infinite;
        }
        h6 {
        font-size: 13px;
        text-align: center;
        }
    </style>

</div>
<div class="floating-window">
                <p>上仙社区<h5>主号VX：sxian0001<br>（频繁 24小时后可以通过好友）</h5><br><h5>备用VX：sxian0003</h5></p><br><p>专注优质互联网项目</p>
                <div class="but">
                <button class="cancel">关闭</button><button class="save">保存</button>
                </div>
                <h6>温馨提示：<br>修改备注或添加信息保存后<br>需刷新页面才可以显示最新状态</h6>
                </div>
        `;

        panel.innerHTML = html;
        document.body.appendChild(panel);//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

        // 绑定事件
        panel.querySelector('.save').addEventListener('click', () => {//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            savedData.groups = [];
            for(let i = 0; i < 10; i++) {
                savedData.groups.push({
                    name: panel.querySelector(`.name-input[data-group="${i}"]`).value,
                    idCard: panel.querySelector(`.idcard-input[data-group="${i}"]`).value,
                    phone: panel.querySelector(`.phone-input[data-group="${i}"]`).value,
                    bankBranch: panel.querySelector(`.branch-input[data-group="${i}"]`).value,//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                    reservationAmount: panel.querySelector(`.amount-input[data-group="${i}"]`).value,
                    note: panel.querySelector(`.note-input[data-group="${i}"]`).value
                });//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            }
            GM_setValue('autofillData', savedData);
            panel.style.display = 'none';
        });

        panel.querySelector('.cancel').addEventListener('click', () => {
            panel.style.display = 'none';//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        });
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        return panel;
    }

    function autoFillForm(groupIndex) {
        const personalInfo = savedData.groups[groupIndex];//上仙社区版权 vx：sxian0001       侵权必究！！！


        const nameInputs = document.querySelectorAll('input[type="text"]');
        nameInputs.forEach(input => {
            const inputId = (input.id || '').toLowerCase();//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            const inputName = (input.name || '').toLowerCase();
            const inputPlaceholder = (input.placeholder || '').toLowerCase();//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            const inputLabel = input.labels && input.labels[0] ? input.labels[0].textContent.toLowerCase() : '';

            if (
                inputId.includes('name') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001     //上仙社区//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！  侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('name') ||
                inputId.includes('oppAcNme') ||
                inputName.includes('oppAcNme') ||
                inputId.includes('usr_nm') ||
                inputName.includes('usr_nm') ||
                inputPlaceholder.includes('姓名') ||
                inputPlaceholder.includes('name') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputId.includes('客户') ||
                inputName.includes('客户') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('客户') ||
                inputLabel.includes('姓名') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('客户') ||
                inputId.includes('username') ||
                inputName.includes('username') ||
                inputId.includes('fullname') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('fullname') ||
                inputId.includes('realname') ||
                inputName.includes('realname') ||
                inputPlaceholder.includes('真实姓名') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('真实姓名') ||
                inputId.includes('客户姓名') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('客户姓名') ||
                inputPlaceholder.includes('客户姓名') ||
                inputLabel.includes('客户姓名') ||
                (inputId.includes('客户') && inputId.includes('姓名')) ||
                (inputName.includes('客户') && inputName.includes('姓名')) ||
                (inputPlaceholder.includes('客户') && inputPlaceholder.includes('姓名'))
            ) {
                input.value = personalInfo.name;//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

        const idInputs = document.querySelectorAll('input');
        idInputs.forEach(input => {
            const inputId = (input.id || '').toLowerCase();
            const inputName = (input.name || '').toLowerCase();
            const inputPlaceholder = (input.placeholder || '').toLowerCase();//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            const inputLabel = input.labels && input.labels[0] ? input.labels[0].textContent.toLowerCase() : '';

            if (//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputId.includes('id') ||
                inputName.includes('id') ||
                inputId.includes('credNumTemp') ||
                inputName.includes('credNumTemp') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputId.includes('.credNumTemp') ||
                inputName.includes('.credNumTemp') ||
                inputId.includes('#credNumTemp') ||
                inputName.includes('#credNumTemp') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputId.includes('证件号码') ||
                inputName.includes('证件号码') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputId.includes('hidden') ||
                inputName.includes('hidden') ||
                inputId.includes('credNumTemp1') ||
                inputName.includes('credNumTemp1') ||
                inputId.includes('crdt_no') ||
                inputName.includes('crdt_no') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('身份证') ||
                inputPlaceholder.includes('证件') ||
                inputPlaceholder.includes('证件号码') ||
                inputPlaceholder.includes('证件号码') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('credNumTemp') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('credNumTemp') ||
                inputLabel.includes('身份证') ||
                inputLabel.includes('证件号') ||
                inputLabel.includes('证件号码') ||
                inputLabel.includes('证件号码') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('credNumTemp') ||
                inputLabel.includes('credNumTemp') ||
                inputId.includes('idcard') ||//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('idcard') ||
                inputId.includes('idnumber') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('idnumber')//上仙社区版权 vx：sxian0001       侵权必究！！！
            ) {
                input.value = personalInfo.idCard;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            }//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        });//上仙社区版权 vx：sxian0001       侵权必究！！！

     
        const phoneInputs = document.querySelectorAll('input[type="tel"], input[type="text"], input[type="number"]');
        phoneInputs.forEach(input => {
            const inputId = (input.id || '').toLowerCase();
            const inputName = (input.name || '').toLowerCase();
            const inputPlaceholder = (input.placeholder || '').toLowerCase();//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            const inputLabel = input.labels && input.labels[0] ? input.labels[0].textContent.toLowerCase() : '';

            if (
                inputId.includes('phone') ||
                inputId.includes('mobile') ||
                inputName.includes('phone') ||
                inputName.includes('mobile') ||
                inputId.includes('secure-input-plain-phone') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('secure-input-plain-phone') ||
                inputId.includes('el-form-item__content') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('el-form-item__content') ||
                inputId.includes('el-form-item') ||
                inputName.includes('el-form-item') ||
                inputId.includes('safe-input') ||
                inputName.includes('safe-input') ||
                inputId.includes('mblph_no') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('mblph_no') ||
                inputPlaceholder.includes('手机') ||
                inputPlaceholder.includes('电话') ||
                inputLabel.includes('手机') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('电话') ||
                inputId.includes('tel') ||
                inputName.includes('tel') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('联系方式') ||
                inputId.includes('cellphone') ||
                inputName.includes('cellphone') ||
                inputId.includes('telephone') ||
                inputName.includes('telephone') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('手机号码') ||
                inputPlaceholder.includes('手机号') ||
                inputLabel.includes('手机号码') ||
                inputLabel.includes('手机号') ||
                inputPlaceholder.includes('联系电话') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('联系电话') ||
                inputId.includes('客户手机') ||
                inputName.includes('客户手机') ||
                inputPlaceholder.includes('客户手机') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('客户手机') ||
                (inputId.includes('客户') && (inputId.includes('手机') || inputId.includes('电话'))) ||
                (inputName.includes('客户') && (inputName.includes('手机') || inputName.includes('电话'))) ||
                (inputPlaceholder.includes('客户') && (inputPlaceholder.includes('手机') || inputPlaceholder.includes('电话'))) ||
                (inputLabel.includes('客户') && (inputLabel.includes('手机') || inputLabel.includes('电话'))) ||
                inputPlaceholder.includes('移动电话') ||
                inputLabel.includes('移动电话') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputId.includes('联系人手机') ||
                inputName.includes('联系人手机') ||
                inputPlaceholder.includes('联系人手机') ||//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputLabel.includes('联系人手机')
            ) {
                input.value = personalInfo.phone;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            }
        });

    
        const branchInputs = document.querySelectorAll('input[type="text"], select');
        branchInputs.forEach(input => {//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
            const inputId = (input.id || '').toLowerCase();
            const inputName = (input.name || '').toLowerCase();
            const inputPlaceholder = (input.placeholder || '').toLowerCase();
            const inputLabel = input.labels && input.labels[0] ? input.labels[0].textContent.toLowerCase() : '';

            if (
                inputId.includes('branch') ||
                inputName.includes('branch') ||//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('网点') ||
                inputLabel.includes('网点') ||
                inputId.includes('bank') ||
                inputName.includes('bank') ||//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('银行') ||
                inputLabel.includes('银行') ||
                inputId.includes('兑换') ||
                inputName.includes('兑换') ||
                inputPlaceholder.includes('兑换') ||
                inputLabel.includes('兑换') ||
                inputId.includes('领取') ||
                inputName.includes('领取') ||
                inputPlaceholder.includes('领取') ||
                inputLabel.includes('领取') ||
                inputId.includes('选择') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputName.includes('选择') ||
                inputPlaceholder.includes('选择') ||
                inputLabel.includes('选择')
            ) {
                if (input.tagName.toLowerCase() === 'select') {
                
                    const options = input.querySelectorAll('option');
                    options.forEach(option => {
                        if (option.textContent.includes(personalInfo.bankBranch)) {
                            option.selected = true;
                            input.dispatchEvent(new Event('change', { bubbles: true }));//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                        }
                    });
                } else {
                 
                    input.value = personalInfo.bankBranch;
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                }
            }
        });

        const amountInputs = document.querySelectorAll('input[type="number"], input[type="text"]');//上仙社区版权 vx：sxian0001       侵权必究！！！
        amountInputs.forEach(input => {
            const inputId = (input.id || '').toLowerCase();
            const inputName = (input.name || '').toLowerCase();
            const inputPlaceholder = (input.placeholder || '').toLowerCase();
            const inputLabel = input.labels && input.labels[0] ? input.labels[0].textContent.toLowerCase() : '';

            if (
                inputId.includes('amount') ||
                inputName.includes('amount') ||
                inputPlaceholder.includes('数量') ||
                inputLabel.includes('数量') ||
                inputId.includes('预约') ||
                inputName.includes('预约') ||
                inputPlaceholder.includes('预约') ||
                inputLabel.includes('预约') ||
                inputId.includes('兑换') ||
                inputName.includes('兑换') ||//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
                inputPlaceholder.includes('兑换') ||
                inputLabel.includes('兑换')
            ) {
                input.value = personalInfo.reservationAmount;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
    }


    function createAnnouncement() {
        const announcement = document.createElement('div');
        announcement.style.position = 'fixed';
        announcement.style.top = '50%';
        announcement.style.left = '50%';
        announcement.style.transform = 'translate(-50%, -50%)';
        announcement.style.background = 'rgba(255, 255, 255, 0.9)';
        announcement.style.padding = '20px';
        announcement.style.borderRadius = '8px';
        announcement.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
        announcement.style.zIndex = '10002';
        announcement.style.maxWidth = '90vw';
        announcement.style.width = '600px'; 
        announcement.style.maxHeight = '80vh'; 
        announcement.style.overflowY = 'auto'; //上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        announcement.style.textAlign = 'center';

        announcement.innerHTML = `
            <h3>公告</h3>
            <p>如果你觉得本脚本够良心，请你在能力之中帮帮作者吧！<br>
            如果作者收费，使用近5000+的人数使用，收费100软妹币.<br>
            就算最后只有将近一半的好兄弟选择付费，作者能有25万的收入.<br>
            作者没有去选择收费使用，而是为爱发电，让好兄弟们约上蛇钞.<br>
            历时半月，近4次更新，从支持四大行近而支持全部承办纪念币银行.<br>
            从支持自动填充三要素到后面一键填充全部可以填充的空位.<br>
            感谢大家陪伴！！！作者也要吃饭，几天的熬夜苦战更新！！！<br>
            最后谢过各位，如果理想的，之后我的所有脚本都不会收费！！！<br>
            下一年的时间继续给大家提供更好用的软件脚本插件！！！<br>
            更重要的是我的好兄弟们 免费！！免费！！免费！！！</p>
            <img src="https://www.helloimg.com/i/2024/12/21/6765d82561032.png" alt="下载.png" title="下载.png" />
            <h1>有打赏的兄弟带截图找我进VIP群</h1>
            <div style="margin-top: 10px;">
                <input type="checkbox" id="dontShowAgainCheckbox" style="margin-right: 5px;">
                <label for="dontShowAgainCheckbox">考虑弹窗影响纪念币预约已关闭</label>
                <h1>为了维护vip群利益，vip群特殊版支持bp链接填写</h1>
                <br>
                <button class="close-announcement" style="padding: 8px 20px; border: none; border-radius: 4px; cursor: pointer; background: #4CAF50; color: white;">我知道了</button>
            </div>
        `;

 
        announcement.querySelector('.close-announcement').addEventListener('click', () => {
            const dontShowAgain = document.getElementById('dontShowAgainCheckbox').checked;
            if (dontShowAgain) {
                const currentTime = new Date().getTime();
                GM_setValue('announcementLastClosed', currentTime);
            }
            announcement.style.display = 'none';
        });

        document.body.appendChild(announcement);
    }//上仙社区版权 vx：sxian0001       侵权必究！！！

   
    function createButtons() {
        const buttonsContainer = document.createElement('div');
        buttonsContainer.className = 'autofill-buttons';

   
        savedData.groups.forEach((group, index) => {
            if (group.name.trim() !== '') { 
                const button = document.createElement('button');
                button.className = 'autofill-button';
                const note = group.note;
                button.textContent = note ? note : `填充第 ${index + 1} 组`;
                button.style.background = 'linear-gradient(to right, #228B22, #66CDAA)';
                button.addEventListener('click', () => {
                    autoFillForm(index);
                    button.textContent = note ? note : `已填充第 ${index + 1} 组`;
                    setTimeout(() => {
                        button.textContent = note ? note : `填充第 ${index + 1} 组`;
                    }, 1000);
                });
                buttonsContainer.appendChild(button);
            }
        });//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！

     
        const settingsButton = document.createElement('button');
        settingsButton.className = 'autofill-button settings-button';
        settingsButton.textContent = '设置';
        settingsButton.style.background = 'linear-gradient(to right, #1E90FF, #00BFFF)'; 
        settingsButton.addEventListener('click', () => {
            const panel = document.querySelector('.autofill-settings');
            panel.style.display = 'block';
        });
        buttonsContainer.appendChild(settingsButton);

        document.body.appendChild(buttonsContainer);

     
        const contactAuthorButton = document.createElement('button');
        contactAuthorButton.className = 'autofill-button';
        contactAuthorButton.textContent = '联系作者';
        contactAuthorButton.style.background = 'linear-gradient(to right, #800080, #DA70D6)'; 
        contactAuthorButton.addEventListener('click', () => {
            window.open('http://107.151.246.181:688/jnbmoni/img/123.jpg', '_blank');
        });
        buttonsContainer.appendChild(contactAuthorButton);
//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！//上仙社区版权 vx：sxian0001       侵权必究！！！
        const coinReservationButton = document.createElement('button');
        coinReservationButton.className = 'autofill-button';
        coinReservationButton.textContent = '纪念币银行预约模拟';
        coinReservationButton.style.background = 'linear-gradient(to right, #FF8C00, #FF4500)'; 
        coinReservationButton.addEventListener('click', () => {
            window.open('http://107.151.246.181:688/jnbmoni', '_blank');
        });
        buttonsContainer.appendChild(coinReservationButton);

      
        const backupCoinReservationButton = document.createElement('button');
        backupCoinReservationButton.className = 'autofill-button';
        backupCoinReservationButton.textContent = '纪念币预约模拟备用站';
        backupCoinReservationButton.style.background = 'linear-gradient(to right, #FF8C00, #FF4500)'; 
        backupCoinReservationButton.addEventListener('click', () => {
            window.open('http://94.74.100.171/jnbmoni', '_blank');
        });
        buttonsContainer.appendChild(backupCoinReservationButton);
    }//上仙社区版权 vx：sxian0001       侵权必究！！！

  
    function init() {
        const settingsPanel = createSettingsPanel();
        createButtons();

        const hasShownAnnouncement = GM_getValue('hasShownAnnouncement', false);

        if (!hasShownAnnouncement) {
            createAnnouncement(); 
            GM_setValue('hasShownAnnouncement', true);
        }


    }
                                                                                            //上仙社区版权 vx：sxian0001       侵权必究！！！

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();